function submitName() {
  let name = document.getElementById("name-input").value;
  let greeting = document.getElementById("greeting");
  greeting.innerText = "Hello World, My name is " + name;
}

let clicked = false;
function changeFontSize() {
  if (clicked === false) {
    clicked = true;
    document.getElementById("demo").style.fontSize = "35px";
  } else if (clicked === true) {
    clicked = false;
    document.getElementById("demo").style.fontSize = "15px";
  }
}

function headsUp() {
  let alertText = document.getElementById("alert").value;
  window.alert(alertText);
}
